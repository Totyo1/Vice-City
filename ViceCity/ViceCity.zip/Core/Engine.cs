﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViceCity.Core.Contracts
{
    class Engine : IEngine
    {
        public void Run()
        {
            throw new NotImplementedException();
        }
    }
}
