﻿using ViceCity.Core;
using ViceCity.Core.Contracts;
using System;
using ViceCity.Models.Guns;

namespace ViceCity
{
    public class StartUp
    {
        
        public static void Main(string[] args)
        {

           
            
            
        }
    }
}
